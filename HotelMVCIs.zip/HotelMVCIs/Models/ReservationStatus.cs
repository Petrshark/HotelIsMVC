﻿namespace HotelMVCIs.Models
{
    public enum ReservationStatus
    {
        Confirmed,
        CheckedIn,
        CheckedOut,
        Cancelled,
        Option
    }
}