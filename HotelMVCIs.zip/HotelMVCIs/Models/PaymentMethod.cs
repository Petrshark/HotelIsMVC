﻿namespace HotelMVCIs.Models
{
    public enum PaymentMethod
    {
        Hotovost = 1,
        Karta = 2,
        Prevod = 3,
        Online = 4,
        Faktura = 5,
        Jine = 6
    }
}