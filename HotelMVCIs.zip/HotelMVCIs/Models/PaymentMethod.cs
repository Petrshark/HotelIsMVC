﻿namespace HotelMVCIs.Models
{
    public enum PaymentMethod
    {
        Hotovost, 
        Karta,    
        Prevod,   
        Online,   
        Jine,
        Faktura
    }
}