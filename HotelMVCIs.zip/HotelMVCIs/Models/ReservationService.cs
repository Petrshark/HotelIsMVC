﻿// Soubor: Models/ReservationService.cs
using System.ComponentModel.DataAnnotations.Schema;

namespace HotelMVCIs.Models
{
    public class ReservationService
    {
        public int ReservationId { get; set; }
        public Reservation Reservation { get; set; }

        public int HotelServiceId { get; set; }
        public HotelService HotelService { get; set; }

        public int Quantity { get; set; } // Počet kusů (např. 2x snídaně)

        [Column(TypeName = "decimal(10, 2)")]
        public decimal PriceAtTimeOfBooking { get; set; } // Cena služby v momentě přidání
    }
}