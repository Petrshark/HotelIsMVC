﻿using HotelMVCIs.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace HotelMVCIs.Controllers
{
    [Authorize]
    public class BookingChartController : Controller
    {
        private readonly BookingChartService _chartService;

        public BookingChartController(BookingChartService chartService)
        {
            _chartService = chartService;
        }

        public async Task<IActionResult> Index(int? year, int? month)
        {
            DateTime dateToShow = (year.HasValue && month.HasValue)
                ? new DateTime(year.Value, month.Value, 1)
                : DateTime.Today;

            var chartData = await _chartService.GetBookingChartAsync(dateToShow);
            return View(chartData);
        }
    }
}