﻿using HotelMVCIs.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelMVCIs.Data
{
    public class HotelMVCIsDbContext : DbContext
    {
        public HotelMVCIsDbContext(DbContextOptions<HotelMVCIsDbContext> options) : base(options)
        {
        }
        public DbSet<RoomType> RoomTypes { get; set; }
        public DbSet<Room> Rooms { get; set; }
        public DbSet<Guest> Guests { get; set; }
        public DbSet<Reservation> Reservations { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<HotelService> HotelServices { get; set; }
        public DbSet<ReservationService> ReservationServices { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Konfigurace pro spojovací tabulku ReservationService
            modelBuilder.Entity<ReservationService>()
                .HasKey(rs => new { rs.ReservationId, rs.HotelServiceId }); // Složený primární klíč

            modelBuilder.Entity<ReservationService>()
                .HasOne(rs => rs.Reservation)
                .WithMany(r => r.ReservationServices)
                .HasForeignKey(rs => rs.ReservationId);

            modelBuilder.Entity<ReservationService>()
                .HasOne(rs => rs.HotelService)
                .WithMany(hs => hs.ReservationServices)
                .HasForeignKey(rs => hs.HotelServiceId);

            // ... tvůj stávající kód pro HasData ...
        }

    }
}